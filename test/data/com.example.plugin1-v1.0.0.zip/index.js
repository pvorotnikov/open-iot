
function init(plugins) {
    console.log('Plugin initialized')
}

module.exports = {
    init,
}
